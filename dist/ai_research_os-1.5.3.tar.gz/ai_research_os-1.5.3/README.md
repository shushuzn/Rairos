# AI Research OS

<div align="center">
  <img src="logo_hero.png" width="800" alt="AI Research OS Demo"/>
</div>

**A Self-Evolving Research Operating System for AI Researchers**

[![Python](https://img.shields.io/badge/Python-3.9%2B-blue)](https://python.org)
[![Tests](https://github.com/shushuzn/ai_research_os/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/shushuzn/ai_research_os/actions)
[![License](https://img.shields.io/badge/License-GPL--3.0--or--later-orange)](#license)

## What It Does

AI Research OS is a **self-evolving research system** that learns from your usage patterns. It's not just a paper manager — it's a research partner that grows smarter over time.

Feed it a paper (arXiv URL, DOI, or PDF). Get back a **P-Note**, **C-Note**, **Radar entry**, and **Timeline entry** — all structured, tagged, and cross-linked.

| Input | Output |
|---|---|
| arXiv URL/ID | P-Note + C-Note + Radar + Timeline |
| DOI | P-Note + C-Note + Radar + Timeline |
| Local PDF | P-Note + C-Note + Radar + Timeline |
| Scanned PDF | Same (via OCR) |

This is **not a PDF manager**. It is a **Self-Evolving System** that:
- Learns from your research patterns
- Improves answers over time
- Adapts to your specific domain

## Core Features

| Feature | Description |
|---------|-------------|
| `airos import` | Import papers from arXiv, DOI, PDF |
| `airos chat` | RAG-powered Q&A with your papers |
| `airos slides` | Auto-generate presentations |
| `airos kg` | Knowledge graph visualization |
| Evolution | Self-improvement via Gene/Capsule patterns |

## Quick Start

```bash
pip install requests feedparser pymupdf
```

### One paper

```bash
# arXiv URL
python -m cli 2601.00155 --tags LLM,Agent

# DOI
python -m cli 10.48550/arXiv.2601.00155 --tags LLM

# Local PDF (with OCR for scanned PDFs)
python -m cli test --pdf "paper.pdf" --tags RAG
python -m cli test --pdf "scanned.pdf" --ocr --ocr-lang chi_sim+eng
```

### Three core commands

```bash
python -m cli import 2601.00155 10.1038/nature12373   # Add papers to DB
python -m cli search "attention mechanism" --tag LLM     # Search papers
python -m cli research "RLHF alignment" --limit 5        # Autonomous research loop
```

### AI draft (optional)

```bash
export OPENAI_API_KEY="sk-..."
export OPENAI_BASE_URL="https://dashscope.aliyuncs.com/compatible-mode/v1"

python -m cli 2601.00155 --tags LLM --ai
```

For full configuration, see [API_CONFIG.md](API_CONFIG.md).

## Research Tree

Papers are organized into 12 directories:

```
00-Radar/            Topic heat tracking
01-Foundations/      Foundational papers
02-Models/           Model papers
03-Training/         Training methods
04-Scaling/         Scaling laws
05-Alignment/        Alignment research
06-Agents/           Agent systems
07-Infrastructure/    Infrastructure
08-Optimization/     Optimization techniques
09-Evaluation/       Evaluation methods
10-Applications/     Applied research
11-Future-Directions/
```

## Knowledge Evolution

```
Paper → P-Note (paper note, per paper)
      → C-Note (concept note, per tag)
      → M-Note (comparison note, when 3+ papers share same tag)
      → Radar (topic frequency heat score)
      → Timeline (year-based evolution)
```

## Recommended Workflow

1. Read 1 paper daily
2. Assign 1–3 tags
3. Weekly check Radar
4. Auto-trigger M-Notes when 3+ papers share a tag
5. Quarterly review Timeline

## All Commands

Run `python -m cli <command> --help` for any command. Key commands:

| Command | Description |
|---|---|
| `import` | Add papers by arXiv ID / DOI / UID |
| `search` | Full-text search with filters |
| `list` | List papers with sort/filter/export |
| `research` | Autonomous research loop (search → download → extract → AI summarize) |
| `stats` | DB overview |
| `export` | Export DB to CSV or JSON |
| `citations` | Show citation relationships |
| `kg` | Knowledge graph query and rebuild |
| `gap` | Detect research gaps and generate research questions |
| `similar` | Find semantically similar papers |
| `dedup` | Find exact duplicates |
| `dedup-semantic` | Semantic deduplication |
| `paper2code` | Generate code from paper |
| `rag` | RAG pipeline (paper2code + tests + benchmark) |
| `benchmark` | Cross-paper benchmark comparison with D3.js/SVG charts |
| `postprocess` | Run deep-dive analysis pipeline on papers |
| `chat-tui` | Full-screen TUI chat with paper context sidebar |
| `litreview` | Incremental literature review with vector search |
| `subscribe` | Subscribe to paper feeds by tag/query |
| `session` | Manage chat sessions |
| `route` | Semantic routing for queries |
| `visual` | Table/figure extraction and visualization |
| `cite-graph` | Citation graph visualization |
| `cite-backfill` | Backfill citation data |
| `ask` | Quick Q&A against paper library |
| `argue` | Debate/gap analysis between papers |
| `narrative` | Generate narrative summaries |

For the complete command reference, see [ADVANCED_COMMANDS.md](ADVANCED_COMMANDS.md).
For Chinese documentation, see [README.zh-CN.md](README.zh-CN.md).

## Shell Completions

Install tab completion for your shell:

```bash
# Fish
cp completions/fish ~/.config/fish/completions/airos.fish

# Zsh
cp completions/zsh _airos ~/.zsh/completion/_airos

# Bash
source completions/bash
# Or: cp completions/bash /etc/bash_completion.d/airos
```

After installation, `airos <Tab>` and `python -m cli <Tab>` will show all 23 subcommands with descriptions.

## Testing

```bash
python -B -m pytest tests/ -q
```

## License {#license}

GNU General Public License v3.0
