"""AI draft generation for P-Notes and C-Notes.

Output format: Markdown sections (human-readable) + XML rubric block (machine-parseable).
Section headings MUST match the P-note template numbering so content can be injected directly.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Tuple, cast

from core import Paper
from llm.client import call_llm_chat_completions

# ------------------------------------------------------------------
# Cost estimation helpers
# ------------------------------------------------------------------

def get_model_price(model: str) -> Tuple[float, float]:
    """Return (input_per_1M, output_per_1M) for a model.

    Prices are loaded from ``config.MODEL_PRICES``, which merges the built-in
    table with any overrides from the ``AIROS_MODEL_PRICES`` env var.
    """
    from config import MODEL_PRICES as _prices
    model_lower = model.lower()
    for prefix, price in _prices.items():
        if prefix in model_lower:
            return price
    return _prices["default"]


def estimate_tokens(text: str) -> int:
    """Estimate token count (≈ chars / 4 for Chinese + English mix)."""
    if not text:
        return 0
    return max(1, len(text) // 4)


def estimate_cost(model: str, input_text: str, output_text: str) -> Dict[str, float]:
    """Estimate cost in USD for a single LLM call."""
    in_per_1m, out_per_1m = get_model_price(model)
    in_toks = estimate_tokens(input_text)
    out_toks = estimate_tokens(output_text)
    return {
        "input_tokens": in_toks,
        "output_tokens": out_toks,
        "total_tokens": in_toks + out_toks,
        "input_cost_usd": round(in_toks / 1_000_000 * in_per_1m, 6),
        "output_cost_usd": round(out_toks / 1_000_000 * out_per_1m, 6),
        "total_cost_usd": round((in_toks / 1_000_000 * in_per_1m) + (out_toks / 1_000_000 * out_per_1m), 6),
    }


# ------------------------------------------------------------------
# P-Note AI draft generation
# ------------------------------------------------------------------
_PNOTE_SYSTEM_PROMPT = """你是一个严谨的 AI 研究助理，擅长对抗式审稿。

任务：为用户的 Research OS P-Note 生成"可编辑初稿"。

硬规则（违反直接输出 [违规]）：
1. 每项 Claims 必须引用原文（用 > 块引用格式），否则写 "[无原文支撑]"，禁止捏造实验/数据/结果
2. 你的判断/推测必须加 [推测] 标注，不能伪装成事实
3. 输出必须是中文 Markdown
4. 每个栏目开头：> AI Draft（可编辑，需人工核验）
5. 只输出指定栏目，不输出额外解释

评分量表 Rubric（在 # 评分量表 栏目末尾必须嵌入 XML 注释）：

Novelty（原创性）:
  1=增量改进/复现；2=组合已有方法；3=新任务/新视角；4=新范式突破；5=开创性/里程碑

Leverage（杠杆效应）:
  1=难以落地；2=需大量适配；3=可直接应用；4=显著降本/提效；5=范式级影响

Evidence（证据强度）:
  1=无实验/toy实验；2=部分任务；3=充分任务覆盖；4=与强基线对比；5=消融/分析完整

Cost（成本/代价）:
  1=极高；2=较高；3=中等；4=较低；5=极低/可忽略

Moat（护城河）:
  1=无壁垒；2=代码；3=数据；4=算法/专利；5=生态/网络效应

Adoption Signal（采纳信号）:
  1=无采纳；2=GitHub<100 stars；3=GitHub>1k/引用>10；4=工业落地；5=生态标配

评分行格式（机器可解析）：`* Novelty (1-5): 3`
"""

_PNOTE_USER_PROMPT_TEMPLATE = """论文标题：{paper_title}
作者：{paper_authors}
来源：{paper_source}:{paper_uid}
发布日期：{paper_published}
标签：{paper_tags}

【Abstract】
{paper_abstract}

【抽取正文片段】（已按重要性排序，高优先级章节有更多内容）

{paper_body}

请按以下栏目生成初稿，## 二级标题必须严格使用给出的编号和名称（内容直接填入对应栏目）：

## 1. 背景
一句话：这篇论文要解决什么问题？（引用摘要）

## 2. 核心问题
这篇论文的核心技术方案是什么？（引用正文片段，用 > 引用；不确定的加 [推测]）

## 3. 方法结构
### 3.1 架构拆解
### 3.2 算法逻辑
### 3.3 关键组件

## 4. 关键创新
一句话总结最大创新点。

## 5. 实验分析
### 5.1 数据集
### 5.2 基线对比
### 5.3 消融实验
### 5.4 成本分析

## 6. 对抗式审稿
列出3个最强质疑点：（1）逻辑/假设漏洞；（2）实验覆盖不足之处；（3）泛化性/复现风险。（加 [推测] 标注）

## 7. 优势
这篇论文的主要优势。（引用参考论文的实验/分析结果支撑）

## 8. 局限
这篇论文的主要局限。（引用参考论文的讨论，加 [推测]）

## 9. 本质抽象
一句话抽象出这篇论文的本质。

## 10. 与其他方法对比
与同类方法的核心差异。

## 11. Decision（决策）
是否值得深入关注？使用场景？

## 12. 知识蒸馏
### Facts
### Principles
### Insights

## 13. 认知升级
长期价值、规模效应、技术护城河、是否范式转移。

## 14. 评分量表
必须包含：Novelty / Leverage / Evidence / Cost / Moat / Adoption Signal
每项格式：`* Novelty (1-5): N`
Overall Judgment：一句话总结

（严禁捏造实验数据；引用格式："> 原文片段"）

在以上 Markdown 内容之后，单独输出以下格式的 JSON（不要放在 XML 注释中，不要加.md后缀）：

```json
{{"novelty": 3, "leverage": 4, "evidence": 3, "cost": 2, "moat": 2, "adoption": 3, "overall": "一句话评价"}}
```
"""


def ai_generate_pnote_draft(
    paper: Paper,
    tags: List[str],
    extracted_text: str,
    base_url: str,
    api_key: str,
    model: str,
    stream: bool = False,
    verbose: bool = False,
    progress_callback: Optional[Callable[..., Any]] = None,
) -> str:
    user_prompt = _PNOTE_USER_PROMPT_TEMPLATE.format(
        paper_title=paper.title,
        paper_authors=", ".join(paper.authors) if paper.authors else "Unknown",
        paper_source=paper.source,
        paper_uid=paper.uid,
        paper_published=paper.published or "N/A",
        paper_tags=", ".join(tags),
        paper_abstract=paper.abstract or "(空)",
        paper_body=extracted_text,
    )

    return cast(str, call_llm_chat_completions(
        messages=[],
        base_url=base_url,
        api_key=api_key,
        model=model,
        system_prompt=_PNOTE_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        stream=stream,
    ))


# =============================================================================
# C-Note AI draft generation
# =============================================================================
_CNOTE_USER_PROMPT_TEMPLATE = """\
概念：{concept}

参考论文（共 {num_papers} 篇）：
{pnotes_text}

请按以下栏目生成 C-Note 初稿，每栏用 ## 二级标题：

## 核心定义
一句话定义这个概念。（引用参考论文中的定义，没有原话则综合推断并加 [推测]）

## 产生背景
这个概念是在什么研究背景下产生的？解决了什么问题？（引用参考论文，没有则 [推测]）

## 技术本质
这个概念的核心技术机制是什么？（引用参考论文，加 [推测] 如需推断）

## 常见实现路径
列出该概念的典型实现方式。（引用参考论文中的实现，加 [推测]）

## 优势
这个概念的主要优势。（引用参考论文的实验/分析结果支撑）

## 局限
这个概念的主要局限。（引用参考论文的讨论，加 [推测]）

## 与其他思想的关系
与其他相关概念的关系和区别。（综合多篇参考论文，加 [推测]）

## 代表论文
从参考论文中选取最能代表该概念的论文，给出选择理由。

## 演化时间线
基于参考论文，推断该概念的演化路径。（加 [推测]）

## 未来趋势
基于参考论文的讨论，预测该概念的未来发展方向。（加 [推测]）

（严禁捏造论文数据；引用格式："> 原文片段"）
"""

_CNOTE_SYSTEM_PROMPT = """你是一个严谨的 AI 研究助理，擅长概念分析和知识图谱构建。

任务：为用户的 Research OS C-Note（概念笔记）生成"可编辑初稿"。

硬规则（违反直接输出 [违规]）：
1. 每项 Claims 必须引用原文（用 > 块引用格式），否则写 "[无原文支撑]"，禁止捏造
2. 你的判断/推测必须加 [推测] 标注，不能伪装成事实
3. 输出必须是中文 Markdown
4. 每个栏目开头：> AI Draft（可编辑，需人工核验）
5. 只输出指定栏目，不输出额外解释
"""


def ai_generate_cnote_draft(
    concept: str,
    pnotes: List[dict],
    api_key: str,
    base_url: str,
    model: str,
    call_llm: Optional[Callable[..., Any]] = None,
) -> str:
    """
    Generate a C-Note draft for a concept using referenced P-Notes as context.

    Args:
        concept: The concept name (e.g. "RAG", "Agent")
        pnotes: List of dicts with keys: title, abstract, authors, year, source, tags
        api_key: LLM API key
        base_url: OpenAI-compatible base URL
        model: Model name
        call_llm: Callable to use instead of the default call_llm_chat_completions.
                  Allows dependency injection for testing.
    """
    if call_llm is None:
        call_llm = call_llm_chat_completions

    pnotes_chunks = [
        f"""\
---
论文 {i}：
标题：{p.get('title', 'N/A')}
作者：{', '.join(p.get('authors', [])) or 'Unknown'}
年份：{p.get('year', 'N/A')}
来源：{p.get('source', 'N/A')}:{p.get('uid', 'N/A')}
标签：{', '.join(p.get('tags', []))}
摘要：{p.get('abstract', '(无)') or '(无)'}
"""
        for i, p in enumerate(pnotes, 1)
    ]
    pnotes_text = "\n".join(pnotes_chunks)

    user_prompt = _CNOTE_USER_PROMPT_TEMPLATE.format(
        concept=concept,
        pnotes_text=pnotes_text,
        num_papers=len(pnotes),
    )

    return cast(str, call_llm(
        base_url=base_url,
        api_key=api_key,
        model=model,
        system_prompt=_CNOTE_SYSTEM_PROMPT,
        user_prompt=user_prompt,
    ))


# ------------------------------------------------------------------
# Read Queue Recommendation Explanation
# ------------------------------------------------------------------
_READ_QUEUE_EXPLANATION_USER_PROMPT_TEMPLATE = """\
## 任务
为以下待推荐论文生成一段中文推荐解释。

## 待推荐论文
- 标题：{paper_title}
- 作者：{paper_authors}
- 年份：{paper_year}
- 领域/分类：{paper_category}

## 推荐评分详情
- 综合得分：{score:.2f}（满分 1.0）
- 语义相似度：{semantic_score:.2f}（权重 40%）
- 引用关系：{citation_score:.2f}（权重 30%）
- 标签重叠：{tag_score:.2f}（权重 20%）
- 时效性：{recency_score:.2f}（权重 10%）
- 最强信号：{top_signal}（{top_value:.2f}）

## 用户已读论文背景
以下是你已经阅读过的论文：
{read_papers_str}

## 输出要求
为这篇待推荐论文生成推荐解释，必须包含以下三个部分：

### 推荐理由
（基于上述评分数据，解释这篇论文为什么被推荐，重点说明得分最高的信号：{top_signal}）

### 与已读论文的关联
（分析这篇论文与你已读论文的联系，说明它在你的研究脉络中的位置）

### 适合阅读的场景
（说明在什么情况下优先阅读这篇论文）

每个部分 2-4 句话，语言精炼，专业易懂。"""

_READ_QUEUE_EXPLANATION_SYSTEM_PROMPT = """你是一个严谨的 AI 研究助理，擅长为用户的阅读队列生成推荐解释。

硬规则：
1. 输出必须是中文 Markdown
2. 只输出推荐解释，不输出额外解释
3. 每个推荐解释控制在 150 字以内
4. 不要捏造论文数据"""


def ai_generate_reading_recommendation_explanation(
    paper_title: str,
    paper_authors: list[str],
    paper_year: str,
    paper_category: str,
    score: float,
    semantic_score: float,
    citation_score: float,
    tag_score: float,
    recency_score: float,
    read_papers_context: list[dict],
    base_url: str,
    api_key: str,
    model: str,
) -> str:
    """Generate Chinese explanation for why a paper is recommended.

    Args:
        paper_title: Paper title
        paper_authors: List of author names
        paper_year: Publication year
        paper_category: Paper category/field
        score: Combined recommendation score
        semantic_score: Semantic similarity score (0-1)
        citation_score: Citation relationship score (0-1)
        tag_score: Tag overlap score (0-1)
        recency_score: Recency score (0-1)
        read_papers_context: List of {title, authors, year, category} for read papers
        base_url: LLM API base URL
        api_key: LLM API key
        model: LLM model name

    Returns:
        Chinese Markdown explanation with three sections:
        - 推荐理由 (Recommendation reason)
        - 与已读论文的关联 (Relation to read papers)
        - 适合阅读的场景 (Best reading scenario)
    """
    authors_str = ", ".join(paper_authors) if paper_authors else "未知"

    # Determine which score is highest
    scores = {
        "语义相似度": semantic_score,
        "引用关系": citation_score,
        "标签重叠": tag_score,
        "时效性": recency_score,
    }
    top_signal = max(scores, key=lambda k: scores[k])
    top_value = scores[top_signal]

    # Format read papers context
    if read_papers_context:
        read_papers_str = "\n".join(
            f"- \"{p['title']}\" by {', '.join(p['authors']) if p['authors'] else '未知'} ({p['year']}), 领域: {p['category'] or 'N/A'}"
            for p in read_papers_context
        )
    else:
        read_papers_str = "（暂无已读论文记录）"

    user_prompt = _READ_QUEUE_EXPLANATION_USER_PROMPT_TEMPLATE.format(
        paper_title=paper_title,
        paper_authors=authors_str,
        paper_year=paper_year,
        paper_category=paper_category or 'N/A',
        score=score,
        semantic_score=semantic_score,
        citation_score=citation_score,
        tag_score=tag_score,
        recency_score=recency_score,
        top_signal=top_signal,
        top_value=top_value,
        read_papers_str=read_papers_str,
    )

    return cast(str, call_llm_chat_completions(
        base_url=base_url,
        api_key=api_key,
        model=model,
        system_prompt=_READ_QUEUE_EXPLANATION_SYSTEM_PROMPT,
        user_prompt=user_prompt,
    ))
