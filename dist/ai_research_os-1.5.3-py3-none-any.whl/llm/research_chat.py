"""Research Chat: AI research assistant with context awareness."""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, cast
from enum import Enum


class QueryType(Enum):
    """Query classification types."""
    FACTUAL = "factual"  # Factual questions
    INFERENTIAL = "inferential"  # Reasoning questions
    DISCOVERY = "discovery"  # Discovery/gap questions
    COMPARISON = "comparison"  # Comparison questions


@dataclass
class PaperContext:
    """Paper context for chat."""
    uid: str
    title: str
    abstract: str
    authors: List[str]
    year: int
    key_findings: List[str] = field(default_factory=list)


@dataclass
class ResearchContext:
    """User's research context."""
    topic: str
    papers: List[PaperContext] = field(default_factory=list)
    insights: List[Any] = field(default_factory=list)  # InsightCard
    relations: Dict[str, List[str]] = field(default_factory=dict)
    citations: Dict[str, List[str]] = field(default_factory=dict)


class ResearchChat:
    """Research chat engine with context awareness."""

    # Chinese and English stopwords for topic extraction
    STOPWORDS = {
        "的", "是", "什么", "如何", "为什么", "有", "哪些", "哪个",
        "和", "与", "在", "了", "都", "也", "要", "能", "可以",
        "the", "a", "an", "is", "are", "was", "were", "what",
        "how", "why", "which", "this", "that", "these", "those",
    }

    def __init__(self, db=None, insight_manager=None, kg=None, api_key=None, base_url=None, model=None):
        self.db = db
        self.insight_manager = insight_manager
        self.kg = kg
        self.api_key = api_key
        self.base_url = base_url
        self.model = model or "qwen3.5-plus"
        self._chat_history: List[Dict[str, str]] = []

    # ── Context Building ────────────────────────────────────

    def build_context(
        self,
        query: str,
        topic_hint: Optional[str] = None,
    ) -> ResearchContext:
        """Build research context from query."""
        topic = topic_hint or self._extract_topic(query)

        # 1. Find relevant papers
        papers = self._find_relevant_papers(topic)

        # 2. Find relevant insights
        insights = []
        if self.insight_manager:
            insights = self.insight_manager.search_cards(query=topic)

        # 3. Build relations (placeholder for future KG integration)
        relations, citations = self._build_relations(papers)

        return ResearchContext(
            topic=topic,
            papers=papers,
            insights=insights,
            relations=relations,
            citations=citations,
        )

    def _extract_topic(self, query: str) -> str:
        """Extract topic from query."""
        import re
        # Tokenize: Chinese sequences (2+ chars) and English words as atomic tokens
        words = re.findall(r'[\u4e00-\u9fff]{2,}|[a-zA-Z]+', query)

        # Filter stopwords and short words
        candidates = [
            w for w in words
            if w.lower() not in self.STOPWORDS and len(w) > 1
        ]

        # Return top 3 candidates joined
        if candidates:
            return " ".join(candidates[:3])
        return query[:20]

    def _find_relevant_papers(
        self,
        topic: str,
        limit: int = 10,
    ) -> List[PaperContext]:
        """Find relevant papers from database."""
        if not self.db:
            return []

        rows, _ = self.db.search_papers(topic, limit=limit)
        return [
            PaperContext(
                uid=r.paper_id,
                title=r.title,
                abstract=getattr(r, "abstract", ""),
                authors=(
                    r.authors
                    if hasattr(r, "authors") and isinstance(r.authors, list)
                    else []
                ),
                year=getattr(r, "year", 2020),
            )
            for r in rows
        ]

    def _build_relations(
        self,
        papers: List[PaperContext],
    ) -> tuple:
        """Build paper relations from the knowledge graph."""
        if not self.kg or not papers:
            return {}, {}

        relations: Dict[str, List[str]] = {}
        citations: Dict[str, List[str]] = {}

        for paper in papers:
            # Find tags for this paper via same_tag edges
            node = self.kg.get_node_by_entity("Paper", paper.uid)
            if not node:
                continue

            edges = self.kg.get_edges_bulk([node["id"]], direction="outgoing", rel_type="same_tag")
            tag_ids = [e["target_id"] for e in edges]

            # Get tag labels
            related_paper_uids: set[str] = set()
            for tag_id in tag_ids:
                tag_node = self.kg.get_nodes_bulk([tag_id]).get(tag_id)
                if not tag_node:
                    continue
                # Find other papers with same tag
                for rp in self.kg.find_papers_by_tag(tag_node["label"]):
                    if rp["entity_id"] != paper.uid:
                        related_paper_uids.add(rp["entity_id"])

            if related_paper_uids:
                relations[paper.uid] = list(related_paper_uids)

            # Cite edges
            cite_edges = self.kg.get_edges_bulk([node["id"]], direction="both", rel_type="cite")
            for e in cite_edges:
                other_id = e["target_id"] if e["source_id"] == node["id"] else e["source_id"]
                other = self.kg.get_nodes_bulk([other_id]).get(other_id)
                if other and other["type"] == "Paper":
                    citations.setdefault(paper.uid, []).append(other["entity_id"])

        return relations, citations

    # ── Query Analysis ──────────────────────────────────────

    def classify_query(self, query: str) -> QueryType:
        """Classify query type."""
        q = query.lower()

        if any(k in q for k in ["对比", "区别", "异同", "哪个更好", "difference", "compare"]):
            return QueryType.COMPARISON
        elif any(k in q for k in ["未解决", "空白", "机会", "还有什么", "gap", "unresolved"]):
            return QueryType.DISCOVERY
        elif any(k in q for k in ["为什么", "原因", "导致", "why", "because", "cause"]):
            return QueryType.INFERENTIAL
        else:
            return QueryType.FACTUAL

    # ── Response Generation ─────────────────────────────────

    def chat(
        self,
        query: str,
        context: Optional[ResearchContext] = None,
    ) -> str:
        """Main chat entry point."""
        ctx = context or self.build_context(query)
        query_type = self.classify_query(query)

        system_prompt = self._build_system_prompt(ctx)
        user_prompt = self._build_user_prompt(query, ctx, query_type)

        response = self._call_llm(system_prompt, user_prompt)

        # Store in history
        self._chat_history.append({"role": "user", "content": query})
        self._chat_history.append({"role": "assistant", "content": response})

        return response

    def _build_system_prompt(self, ctx: ResearchContext) -> str:
        """Build system prompt with context."""
        papers_info = "\n".join([
            f"- {p.title} ({p.year})"
            for p in ctx.papers[:5]
        ]) if ctx.papers else "No relevant papers found"

        insights_info = "\n".join([
            f"- {i.content[:100]}"
            for i in ctx.insights[:3]
        ]) if ctx.insights else "No relevant insights"

        # KG relations: related papers via shared tags
        kg_info = ""
        if ctx.relations:
            paper_titles = {p.uid: p.title for p in ctx.papers}
            lines = []
            for uid, related_uids in list(ctx.relations.items())[:5]:
                src = paper_titles.get(uid, uid)
                related = [paper_titles.get(r, r) for r in related_uids[:3]]
                if related:
                    lines.append(f"- {src} is related to: {', '.join(related)}")
            if lines:
                kg_info = "\nKnowledge graph relations (papers sharing research topics):\n" + "\n".join(lines)

        return f"""You are a research assistant. Answer questions based on the user's research library.

Current research focus: {ctx.topic}

Relevant papers from your library:
{papers_info}
{kg_info}

User's annotated insights:
{insights_info}

Guidelines:
1. Reference specific papers when making claims
2. Synthesize information from multiple sources when possible
3. Acknowledge gaps in the research library
4. Use knowledge graph relations to identify connections between papers
5. Suggest follow-up questions when appropriate"""

    def _build_user_prompt(
        self,
        query: str,
        ctx: ResearchContext,
        query_type: QueryType,
    ) -> str:
        """Build user prompt based on query type."""
        prompts = {
            QueryType.FACTUAL: f"Answer the following question:\n\n{query}",
            QueryType.INFERENTIAL: f"Analyze and reason about:\n\n{query}",
            QueryType.DISCOVERY: f"Identify research gaps and opportunities in:\n\n{query}",
            QueryType.COMPARISON: f"Compare and contrast:\n\n{query}",
        }
        return prompts.get(query_type, query)

    def _call_llm(
        self,
        system_prompt: str,
        user_prompt: str,
    ) -> str:
        """Call LLM API."""
        from llm.client import call_llm_chat_completions

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        return cast(str, call_llm_chat_completions(
            messages=messages,
            model=self.model,
            api_key=self.api_key,
            base_url=self.base_url or "https://api.openai.com/v1",
            system_prompt=None,
        ))

    def chat_stream(
        self,
        query: str,
        context: Optional[ResearchContext] = None,
    ):
        """Stream chat response as an iterator of content deltas."""
        from llm.client import stream_llm_chat_completions

        ctx = context or self.build_context(query)
        query_type = self.classify_query(query)

        system_prompt = self._build_system_prompt(ctx)
        user_prompt = self._build_user_prompt(query, ctx, query_type)

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        full_response = ""
        for delta in stream_llm_chat_completions(
            messages=messages,
            model=self.model,
            api_key=self.api_key,
            base_url=self.base_url or "https://api.openai.com/v1",
            system_prompt=None,
        ):
            yield delta
            full_response += delta

        # Store in history after streaming completes
        self._chat_history.append({"role": "user", "content": query})
        self._chat_history.append({"role": "assistant", "content": full_response})

    def get_history(self) -> List[Dict[str, str]]:
        """Get chat history."""
        return self._chat_history.copy()

    def clear_history(self) -> None:
        """Clear chat history."""
        self._chat_history.clear()
